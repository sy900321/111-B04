# B04 > 2023-04-18 8:19am
https://universe.roboflow.com/pccu-xexew/b04

Provided by a Roboflow user
License: CC BY 4.0

